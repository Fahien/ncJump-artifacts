[![Linux](https://github.com/Fahien/ncJump/workflows/Linux/badge.svg)](https://github.com/Fahien/ncJump/actions?workflow=Linux)
[![macOS](https://github.com/Fahien/ncJump/workflows/macOS/badge.svg)](https://github.com/Fahien/ncJump/actions?workflow=macOS)
[![Windows](https://github.com/Fahien/ncJump/workflows/Windows/badge.svg)](https://github.com/Fahien/ncJump/actions?workflow=Windows)
[![MinGW](https://github.com/Fahien/ncJump/workflows/MinGW/badge.svg)](https://github.com/Fahien/ncJump/actions?workflow=MinGW)
[![Emscripten](https://github.com/Fahien/ncJump/workflows/Emscripten/badge.svg)](https://github.com/Fahien/ncJump/actions?workflow=Emscripten)
[![Android](https://github.com/Fahien/ncJump/workflows/Android/badge.svg)](https://github.com/Fahien/ncJump/actions?workflow=Android)
[![CodeQL](https://github.com/Fahien/ncJump/workflows/CodeQL/badge.svg)](https://github.com/Fahien/ncJump/actions?workflow=CodeQL)

# ncJump
