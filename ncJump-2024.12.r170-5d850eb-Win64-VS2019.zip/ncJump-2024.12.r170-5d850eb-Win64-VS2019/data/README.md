# Data files for the *ncJump* project

## Textures

Some textures used by this project are freely available on itch.io:
- [Pixel art Metroidvania asset pack](https://o-lobster.itch.io/platformmetroidvania-pixel-art-asset-pack) by [o_lobster](https://o-lobster.itch.io/)
- [Nature platofmer tileset](https://rottingpixels.itch.io/nature-platformer-tileset) by [rottingpixels](https://rottingpixels.itch.io/)
- [Castle platofmer tileset](https://rottingpixels.itch.io/castle-platformer-tileset-16x16free) by [rottingpixels](https://rottingpixels.itch.io/)
